# 008 - Implementation Plan

## Fase 1 - Setup
- crear monorepo simple
- preparar apps y packages
- configurar lint/format
- docker compose con PostgreSQL
- preparar variables de entorno

## Fase 2 - Backend base
- FastAPI app
- settings
- routers
- models
- schemas
- migraciones
- healthcheck
- logging

## Fase 3 - Frontend base
- Next.js app
- layout portrait kiosk
- design system
- home
- navegación
- manejo de sesión
- bot animado

## Fase 4 - Perfilamiento
- pantallas de preguntas
- persistencia de respuestas
- progreso
- recuperación de sesión

## Fase 5 - Recomendación
- backend de recomendación
- cards de resultados
- explicación básica
- estados sin resultados

## Fase 6 - Derivación
- generación de lead
- resumen ejecutivo
- dashboard básico

## Fase 7 - LLM y QA
- integración LLM controlada
- pruebas
- hardening
- staging
