# 002 - UX Spec

## Principios UX
- 1 pantalla = 1 decisión
- máximo 3 opciones grandes por pantalla
- máximo 5 preguntas en MVP
- siempre permitir avanzar
- poco texto
- bot visible pero secundario
- diseño premium, limpio y moderno
- soporte táctil optimizado
- contraste alto y lectura simple

## Tono visual
- minimalista
- elegante
- premium
- oscuro con acentos sutiles
- tarjetas limpias
- mucho espacio
- animaciones suaves

## Reglas de interacción
- incluir “Saltar” cuando aplique
- incluir “No estoy seguro” cuando aplique
- permitir volver atrás sin perder la sesión
- persistir respuestas en cada paso
- evitar inputs libres en el MVP salvo casos muy controlados

## Pantallas MVP
1. Home
2. Toma de número
3. Tipo de propiedad
4. Objetivo compra
5. Ubicación
6. Presupuesto/dividendo
7. Subsidio
8. Resultados
9. Derivación
10. Espera / recuperación

## Bot animado
- debe reforzar cercanía
- no debe dominar la pantalla
- no debe tapar CTAs
- debe tener microanimaciones sutiles
- su rol es orientar, no distraer

## Estados
- cargando
- sin resultados
- error de red
- sesión expirada
- sesión recuperada
