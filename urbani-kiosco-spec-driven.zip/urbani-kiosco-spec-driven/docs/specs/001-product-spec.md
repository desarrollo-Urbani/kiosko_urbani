# 001 - Product Spec

## Nombre del producto
Asistente Digital de Sala Urbani

## Visión
Crear un kiosco táctil inteligente para sala de ventas inmobiliaria que ordene la demanda, mejore la experiencia del cliente, capture contexto útil para el ejecutivo y aumente la probabilidad de conversión.

## Problema que resuelve
- tiempos muertos en sala de ventas
- baja captura de intención real del cliente
- perfilamiento inconsistente entre ejecutivos
- poca preparación del ejecutivo antes de atender
- pérdida de oportunidades por fricción
- baja continuidad entre experiencia física y seguimiento comercial

## Propuesta de valor
- entregar número de atención
- permitir perfilamiento en 30 a 90 segundos
- recomendar opciones de propiedades con lógica útil
- generar un resumen ejecutivo accionable
- acompañar al usuario con IA sin incomodarlo

## Actores
- visitante de sala
- ejecutivo comercial
- supervisor comercial
- administrador del sistema
- motor de recomendación
- asistente conversacional

## Entradas principales del usuario
1. Sacar número
2. Buscar propiedad
3. Explorar

## Objetivos del MVP
- capturar sesiones de kiosco
- emitir tickets de atención
- realizar perfilamiento corto
- generar recomendaciones iniciales
- crear lead resumido para el ejecutivo
- registrar eventos UX y métricas básicas

## No objetivos del MVP
- scoring crediticio real
- integración bancaria
- voz
- continuidad omnicanal completa
- personalización avanzada por historial largo

## KPIs
- sesiones iniciadas
- tickets emitidos
- perfilamientos completados
- tasa de abandono
- tiempo promedio por pantalla
- leads generados
- recomendaciones vistas
- derivaciones a ejecutivo

## Riesgos
- exceso de preguntas
- dependencia excesiva del LLM
- recomendaciones sin stock válido
- integración CRM tardía
- baja adopción en sala

## Criterio de éxito
El MVP debe demostrar que puede ordenar la atención, capturar intención comercial y dejar al ejecutivo mejor preparado que en el flujo actual.
