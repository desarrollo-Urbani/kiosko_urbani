# 003 - Business Rules

## 1. Turnero
- Si el usuario elige Sacar número, crear ticket.
- Si nombre o teléfono están vacíos, el ticket igual debe emitirse.
- El ticket debe tener número correlativo y timestamp.
- El ticket debe registrar motivo de atención si fue seleccionado.
- Si el sistema no puede calcular espera, mostrar ticket sin ETA.

## 2. Perfilamiento
- No bloquear flujo por respuestas faltantes.
- Si el usuario elige “No estoy seguro”, continuar.
- Si el usuario elige “Saltar”, guardar evento UX.
- Máximo 5 preguntas en MVP.
- Cada respuesta debe persistirse de inmediato.
- Se puede finalizar el flujo con respuestas parciales.

## 3. Recomendación
- Nunca usar el LLM para decidir recomendaciones.
- La recomendación MVP usa filtros y score simple.
- Nunca recomendar propiedades sin stock válido.
- Si faltan datos, usar fallback por tipo y rango aproximado.
- Entregar entre 3 y 5 resultados cuando existan suficientes opciones.

## 4. LLM
- Puede reformular preguntas.
- Puede explicar opciones.
- Puede acompañar la indecisión.
- No puede inventar stock, precios, subsidios ni condiciones.
- No puede modificar el scoring.

## 5. Lead y resumen
- Si el usuario completa al menos un dato útil y llega a cierre, crear lead.
- El resumen ejecutivo debe incluir tipo, zona, rango de presupuesto, intención y estado del perfil.
- El lead puede quedar como parcial si faltan datos.

## 6. Analítica
- Registrar entrada a pantalla.
- Registrar abandono por pantalla.
- Registrar clics principales.
- Registrar emisión de ticket.
- Registrar generación de lead.
