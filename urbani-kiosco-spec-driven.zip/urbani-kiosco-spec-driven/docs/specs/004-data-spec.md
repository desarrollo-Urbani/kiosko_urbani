# 004 - Data Spec

## Base de datos
PostgreSQL

## Entidades principales
- kiosk_sessions
- session_answers
- queue_tickets
- properties
- projects
- recommendation_runs
- recommendation_items
- leads
- lead_summaries
- ux_events

## Diseño general

### kiosk_sessions
- id
- session_key
- status
- entry_mode
- started_at
- finished_at
- last_activity_at

### session_answers
- id
- session_id
- question_key
- answer_value
- answer_label
- created_at

### queue_tickets
- id
- session_id
- ticket_number
- attention_reason
- customer_name
- customer_phone
- estimated_wait_minutes
- created_at

### properties
- id
- project_id
- property_type
- bedrooms
- bathrooms
- area_m2
- price
- dividend_estimate
- stock_status
- location_label

### projects
- id
- name
- commune
- city
- delivery_status
- subsidy_available

### recommendation_runs
- id
- session_id
- score_version
- generated_at

### recommendation_items
- id
- recommendation_run_id
- property_id
- match_score
- match_level
- explanation

### leads
- id
- session_id
- lead_status
- interest_type
- property_type
- location_preference
- budget_range
- subsidy_interest
- created_at

### lead_summaries
- id
- lead_id
- executive_summary
- created_at

### ux_events
- id
- session_id
- event_type
- screen_name
- event_payload
- created_at

## Requisitos
- guardar respuestas incompletas
- permitir reanudar sesiones
- permitir auditar recomendaciones
- registrar timestamps en todas las tablas relevantes
