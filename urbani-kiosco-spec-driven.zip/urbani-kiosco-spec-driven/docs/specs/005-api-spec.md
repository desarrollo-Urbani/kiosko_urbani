# 005 - API Spec

## Base
- prefijo: `/api/v1`
- formato: JSON

## Endpoints MVP

### Sessions
- POST /api/v1/sessions
- GET /api/v1/sessions/{session_id}
- POST /api/v1/sessions/{session_id}/answers

### Queue
- POST /api/v1/queue/tickets

### Recommendations
- POST /api/v1/recommendations/run
- GET /api/v1/recommendations/{session_id}

### Leads
- POST /api/v1/leads
- POST /api/v1/leads/{lead_id}/summary

### LLM
- POST /api/v1/llm/assist

### Events
- POST /api/v1/events

### Dashboard
- GET /api/v1/dashboard/leads
- GET /api/v1/dashboard/leads/{lead_id}

## Reglas API
- usar validación estricta en backend
- respuestas consistentes
- códigos HTTP apropiados
- errores serializados
- versionado preparado desde el inicio
