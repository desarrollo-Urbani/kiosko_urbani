# 006 - Recommender Spec

## Objetivo
Entregar 3 a 5 propiedades ordenadas por afinidad usando reglas simples y explicables.

## Inputs
- tipo de propiedad
- ubicación
- rango de precio o dividendo
- objetivo compra
- interés en subsidio
- plazo de compra

## Lógica MVP
1. filtrar por stock válido
2. filtrar por tipo de propiedad si existe
3. filtrar por ubicación preferida si existe
4. filtrar por rango de precio/dividendo si existe
5. ajustar score por subsidio y plazo
6. ordenar por score descendente
7. devolver top 3 a 5

## Explicación
Cada resultado debe incluir una breve explicación:
- coincide con la zona
- calza con el rango
- tipología compatible
- proyecto potencialmente alineado

## Restricciones
- no usar LLM para ranking
- no recomendar resultados sin stock
- si no hay suficientes resultados, relajar filtros en orden controlado
