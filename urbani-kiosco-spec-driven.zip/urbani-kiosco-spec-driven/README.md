# Urbani Kiosco - Base Spec-Driven

Base documental para desarrollar el proyecto **Asistente Digital de Sala Urbani** con metodología **spec-driven** en VS Code usando un agente de desarrollo.

## Objetivo
Construir un kiosco táctil inmobiliario que permita:
- sacar número de atención
- perfilar clientes sin fricción
- recomendar propiedades
- interactuar con un LLM de forma guiada
- derivar al ejecutivo con contexto comercial

## Estructura
- `docs/specs`: especificaciones funcionales y técnicas
- `docs/decisions`: ADRs y decisiones de arquitectura
- `docs/prompts`: prompts operativos para el agente
- `apps/kiosk-web`: frontend del kiosco
- `apps/api`: backend FastAPI
- `packages/shared`: tipos y contratos compartidos
- `packages/ui`: componentes reutilizables
- `infra`: infraestructura y despliegue
- `tests`: pruebas integradas

## Forma de trabajo
1. Crear o refinar specs
2. Aprobar alcance MVP
3. Implementar por módulos
4. Validar contra criterios de aceptación
5. Registrar decisiones en ADRs
